### Hexlet tests and linter status:
[![Actions Status](https://github.com/RochaVerde/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/RochaVerde/python-project-49/actions)
<a href="https://codeclimate.com/github/RochaVerde/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/76836dc7d17b89c443a1/maintainability" /></a>